
document.querySelector("form").addEventListener("submit", function(e) {
  e.preventDefault();
  alert("Message submitted successfully!");
});

// Chart.js example for tourism stats
const ctx = document.getElementById('tourismChart').getContext('2d');
new Chart(ctx, {
  type: 'bar',
  data: {
    labels: ['2019', '2020', '2021', '2022', '2023'],
    datasets: [{
      label: 'Visitors (in Lakhs)',
      data: [71, 25, 45, 68, 75],
      backgroundColor: 'rgba(0, 150, 136, 0.7)',
      borderColor: 'rgba(0, 150, 136, 1)',
      borderWidth: 1
    }]
  },
  options: {
    scales: {
      y: {
        beginAtZero: true
      }
    }
  }
});
